﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost_v1
{
    class Ostacolo : PictureBox
    {
        private PictureBox ostacolo1 { set; get; }

        private PictureBox ostacolo2 { set; get; }

        public Ostacolo(Rettangolo rett1, Rettangolo rett2) : base()
        {
            ostacolo1.SetBounds(rett1.altoSx.getX(), rett1.altoSx.getY(), rett1.width, rett1.height);
            ostacolo2.SetBounds(rett2.altoSx.getX(), rett2.altoSx.getY(), rett2.width, rett2.height);

        }

        public Ostacolo()
        {
            ostacolo1 = new PictureBox();
            ostacolo2 = new PictureBox();
        }



        ///  riceve un personaggio in pers e restituisce true se pers 
        ///si sovrappone a rettangolo1 o rettangolo2.Altrimenti restituisce false
        /// <param name="pers">personaggio da controllare
        /// <returns>booleano che indica se il personaggio HA colpito 
        public bool colpito(Personaggio pers)
        {
            bool colpito = false;

            if (this.ostacolo1.Bounds.IntersectsWith(pers.Bounds))
                colpito = true;

            return colpito;
        }

        /// metodo che serve per disegnare gli ostacoli in modo 
        /// randomico all' interno della mappa,non ha nulla come 
        ///parametro e non restituisce alcun valore in quanto disegna direttamente gli ostacoli 
        public void disegna()
        {

        }



    }
}
