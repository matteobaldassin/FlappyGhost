﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Rettangolo
    {
        private
            Punto altoSx; 
            Punto bassoDx;
       
       public Rettangolo(Punto altoSx , Punto bassoDx)
        {
            this.altoSx = altoSx;
            this.bassoDx = bassoDx;
        }
        public Rettangolo()
        {
            altoSx = new Punto(0,0);
            bassoDx = new Punto(0, 0);
        }

        public Punto getAltoSx()
        {
            return altoSx;
        }
        public Punto getBassoDx()
        {
            return bassoDx;
        }

        public void setAltoSx( Punto altoSx)
        {
            this.altoSx = altoSx;
        }
        public void setBassoDx(Punto bassoDx)
        {
            this.bassoDx = bassoDx;
        }
    }
}
