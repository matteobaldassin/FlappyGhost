﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Ostacolo
    {
       
           private  Rettangolo ostacolo1 , ostacolo2;
        
           public Ostacolo()
        {
            ostacolo1 = new Rettangolo();
            ostacolo2 = new Rettangolo();

        }
        public Ostacolo(Rettangolo rett1,Rettangolo rett2)
        {
            ostacolo1 = rett1;
            ostacolo2 = rett2;
        }
        /// <summary>
        /// 
        /// </summary>
        public void disegna()
        {
            
        }
    }
}
