﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace GestioneFrameImage
{
    class GestioneFrameImage
    {

        //private Image[] Gif;
        //public int numEl { set; get; }
        private Image gifImg;
        
        public GestioneFrameImage(Image Gif)
        {
            this.gifImg = Gif;
        }
        /// <summary>
        /// setta l'immagine della gif con il frame in posizione index
        /// </summary>
        /// <param name="index"></param>
        public void setImageFrame(int index)
        {
            
            FrameDimension dimension = new FrameDimension(gifImg.FrameDimensionsList[0]);
            // Number of frames
            int frameCount = gifImg.GetFrameCount(dimension);
            // Return an Image at a certain index
            gifImg.SelectActiveFrame(dimension, index);
        }
        public void getFrameDuration()
        {
            PropertyItem item = gifImg.GetPropertyItem(0x5100); // FrameDelay in libgdiplus
                                                             // Time is in 1/100ths of a second
            int delay = (item.Value[0] + item.Value[1] * 256) * 10;
        }
    }
}
