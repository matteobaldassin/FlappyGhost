﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestioneFrameImage
{
    public partial class Form1 : Form
    {
        private GestioneFrameImage gif = new GestioneFrameImage(global::GestioneFrameImage.Properties.Resources.Ghost);
        public Form1()
        {
            
            InitializeComponent();
            gif.Start();
        }

        

        private void timer1_Tick(object sender, EventArgs e)
        {
            Invalidate();

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
           // e.Graphics.ScaleTransform(0.5f, 0.5f);
            e.Graphics.DrawImage(gif.getCorrectFrame(),0,0);
        }
    }
}
