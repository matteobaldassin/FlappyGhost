﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestioneFrameImage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();
            draw();
        }

        public void draw()
        {
            GestioneFrameImage gif = new GestioneFrameImage(global::GestioneFrameImage.Properties.Resources.Ghost);

            pictureBox1.Image = gif.setImageFrame(1);
            

        }
    }
}
