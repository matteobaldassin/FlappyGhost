﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost_v1
{
    class Punto 
        
    {
        private Point punto;
        public int X { set; get; }
        public int Y { set; get; }



        public Punto()
        {
            X = 0;
            Y = 0;
        }
        /// <summary>
        /// Inizializza l'oggetto Punto avendo in ingresso le coordinate
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public Punto(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }

        /// <summary>
        /// Cambia il valore di Y
        /// </summary>
        /// <param name="y"></param>
        public void setY(int y)
        {
            this.Y = y;
        }
        /// <summary>
        /// Cambia il valore di X
        /// </summary>
        /// <param name="x"></param>
        public void setX(int x)
        {
            this.X = x;
        }
        public int getX() { return X; }
        public int getY() { return Y; }


    }
}
