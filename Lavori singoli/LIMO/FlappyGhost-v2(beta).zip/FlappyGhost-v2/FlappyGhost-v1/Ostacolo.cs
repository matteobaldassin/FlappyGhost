﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost_v1
{
    class Ostacolo
    {
       
        private Point ostacolo1 { set; get; }

        private Point ostacolo2 { set; get; }

        public Ostacolo(Point pOstacolo1, Point pOstacolo2)
        {
            ostacolo1 = pOstacolo1;
            ostacolo2 = pOstacolo2;
                      
        }

        public Ostacolo()
        {
            ostacolo1 = new Point();
            ostacolo1 = new Point();
        }

        public Point getOstacolo1()
        {
            return ostacolo1;


        }
        public Point getOstacolo2()
        {
            return ostacolo2;


        }



        ///  riceve un personaggio in pers e restituisce true se pers 
        ///si sovrappone a rettangolo1 o rettangolo2.Altrimenti restituisce false
        /// <param name="pers">personaggio da controllare
        /// <returns>booleano che indica se il personaggio HA colpito 
        public bool colpito(Personaggio pers)
        {
           
        }

        /// metodo che serve per disegnare gli ostacoli in modo 
        /// randomico all' interno della mappa,non ha nulla come 
        ///parametro e non restituisce alcun valore in quanto disegna direttamente gli ostacoli 
        



    }
}
