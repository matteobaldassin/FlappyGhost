﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost_v1
{
    public partial class GameControl : UserControl
    {
        
        int OffsetX = 0;
        Ostacolo ostacolo1;

        int Pos = 0;
        int MovimentoMassimo = 1;


        Punto Ghost = new Punto(0,0);
        


        public GameControl()
        {
            InitializeComponent();
            timer1.Enabled = true;
            pictureBox1.Location = new Punto(-200, -200);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            //base.OnPaint(e);
            e.Graphics.DrawImage(FlappyGhost_v3.Properties.Resources.giusta,ostacolo1.getOstacolo1());

        }
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            //base.OnPaintBackground(e);
            
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX, 0);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX+ this.BackgroundImage.Width, 0);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + (this.BackgroundImage.Width*2), 0);

            if (Ghost.Y> Pos)
            {
                if(Ghost.Y- MovimentoMassimo > Pos)
                    Ghost = new Punto(Ghost.X, Ghost.Y- MovimentoMassimo);
                else
                    Ghost = new Punto(Ghost.X, Pos);
            }
            else if (Ghost.Y < Pos)
            {
                if (Ghost.Y + MovimentoMassimo < Pos)
                    Ghost = new Punto(Ghost.X, Ghost.Y + MovimentoMassimo);
                else
                    Ghost = new Punto(Ghost.X, Pos);
            }

            e.Graphics.DrawImage(pictureBox1.Image, Ghost);

        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            OffsetX -= 10;
            if (OffsetX < -this.BackgroundImage.Width)
            {
                OffsetX += this.BackgroundImage.Width;
            }
            Invalidate();
        }

        private void GameControl_Load(object sender, EventArgs e)
        {

        }
        
    }
}
