﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost
{
    public partial class UserControl1 : UserControl
    {
        int OffsetX = 0;
        
        private  Ostacolo ostacolo1 = null;
        private  Ostacolo ostacolo2 = null;
        private  Ostacoli ostacoli = null;
        
        
        



        int Pos = 0;
        int MovimentoMassimo = 1;


        Point Ghost = new Point(0, 0);



        public UserControl1()
        {
            ostacolo1 = new Ostacolo();
            ostacolo2 = new Ostacolo();
            ostacoli = new Ostacoli(ostacolo1, ostacolo2);
            InitializeComponent();
            //timer1.Enabled = true;
            //pictureBox1.Location = new Point(-200, -200);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            //base.OnPaint(e);
            //e.Graphics.DrawImage(FlappyGhost_v3.Properties.Resources.giusta,ostacolo1.getOstacolo1());

        }
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            //base.OnPaintBackground(e);

            e.Graphics.DrawImage(this.BackgroundImage, OffsetX, 0);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + this.BackgroundImage.Width, 0);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + (this.BackgroundImage.Width * 2), 0);

            //ostacoli.setOstacolo1();
            e.Graphics.DrawImage((Image)FlappyGhost.Properties.Resources., ostacolo1.getOstacolo());

            e.Graphics.DrawImage((Image)FlappyGhost.Properties.Resources.Sottosopra, ostacolo2.getOstacolo());


            if (Ghost.Y > Pos)
            {
                if (Ghost.Y - MovimentoMassimo > Pos)
                    Ghost = new Point(Ghost.X, Ghost.Y - MovimentoMassimo);
                else
                    Ghost = new Point(Ghost.X, Pos);
            }
            else if (Ghost.Y < Pos)
            {
                if (Ghost.Y + MovimentoMassimo < Pos)
                    Ghost = new Point(Ghost.X, Ghost.Y + MovimentoMassimo);
                else
                    Ghost = new Point(Ghost.X, Pos);
            }

            //e.Graphics.DrawImage(pictureBox1.Image, Ghost);

        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            OffsetX -= 10;
            if (OffsetX < -this.BackgroundImage.Width)
            {
                OffsetX += this.BackgroundImage.Width;
            }
            Invalidate();
        }

        private void GameControl_Load(object sender, EventArgs e)
        {

        }
    }
}
