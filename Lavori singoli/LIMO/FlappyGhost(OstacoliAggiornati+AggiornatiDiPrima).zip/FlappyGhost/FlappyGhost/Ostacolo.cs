﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Ostacolo
    {

        private Punto ostacolo { set; get; }
        
        private Image img;
        private Rettangolo rect;
        



        public Ostacolo(Punto pOstacolo)
        {
            ostacolo = pOstacolo;
            


        }

        public Ostacolo()
        {
            ostacolo = new Punto(600, 50);

        }

        public Point getOstacolo()
        {
            return ostacolo.getPunto();


        }
        public Punto getPuntoOstacolo()
        {
            return ostacolo;

        }
        public void setOstacolo(Punto p)
        {
            ostacolo = p;
        }
        public int getW()
        {
            return img.Width;
            
        }
        public int getH()
        {
            return img.Height;

        }

        public void setImage(Image ost)
        {
            this.img = ost;



        }
        public Image getImage()
        {
            return img;

        }

        

        

    }
}
