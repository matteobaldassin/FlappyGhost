﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost_v1
{
    class Ostacolo
    {
       
        private Image ostacolo1 { set; get; }

        private Image ostacolo2 { set; get; }

        public Ostacolo(Rettangolo rett1, Rettangolo rett2)
        {
           // Bitmap b = (Bitmap) ostacolo1;
            
            
            

        }

        public Ostacolo()
        {
            


        }



        ///  riceve un personaggio in pers e restituisce true se pers 
        ///si sovrappone a rettangolo1 o rettangolo2.Altrimenti restituisce false
        /// <param name="pers">personaggio da controllare
        /// <returns>booleano che indica se il personaggio HA colpito 
        public bool colpito(Personaggio pers)
        {
            bool colpito = false;
            GraphicsUnit u = new GraphicsUnit();
            if (this.ostacolo1.GetBounds(ref u).IntersectsWith(pers.GetBounds(ref u)))
                colpito = true;

            return colpito;
        }

        /// metodo che serve per disegnare gli ostacoli in modo 
        /// randomico all' interno della mappa,non ha nulla come 
        ///parametro e non restituisce alcun valore in quanto disegna direttamente gli ostacoli 
        public void disegna()
        {

        }



    }
}
