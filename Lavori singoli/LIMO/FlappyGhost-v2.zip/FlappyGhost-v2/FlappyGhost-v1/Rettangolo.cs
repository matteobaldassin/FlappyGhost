﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost_v1
{
    class Rettangolo
    {

        public Punto altoSx { set; get; }
        public int width { set; get; }
        public int height { set; get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="altoSx"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public Rettangolo(Punto altoSx, int width, int height)
        {
            this.altoSx = altoSx;
            this.width = width;
            this.height = height;

        }
        /// <summary>
        /// Costruttore di default
        /// </summary>
        public Rettangolo()
        {
            altoSx = new Punto(0, 0);
            width = 0;
            height = 0;

        }

    }

}
