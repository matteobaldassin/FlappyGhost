﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Ostacoli
    {
        private Ostacolo ostacolo1;
        private Ostacolo ostacolo2;

        public Ostacoli()
        {
            ostacolo1 = new Ostacolo();
            ostacolo2 = new Ostacolo();

        }

        public Ostacoli(Ostacolo ostacolo1, Ostacolo ostacolo2)
        {
            this.ostacolo1 = ostacolo1;
            this.ostacolo2 = ostacolo2;
            ostacolo1.setImage(FlappyGhost.Properties.Resources.Sopra);
            ostacolo2.setOstacolo(FlappyGhost.Properties.Resources.Sotto);

        }


        /// metodi che servono per settare le coordinate degli ostacoli da collocare in modo 
        /// randomico all' interno della mappa,non ha nulla come 
        ///parametro e non restituisce alcun valore
        public void setOstacolo1()
        {
            int y = randInt(450, 50);
            Punto p1 = ostacolo1.getPuntoOstacolo();
            p1.setY(y);
            ostacolo1.setOstacolo(p1);
        }

        public void setOstacolo2()
        {
            Punto p2 = ostacolo2.getPuntoOstacolo();
            int y = (1050 + ostacolo1.getPuntoOstacolo().getY()) + 200;
            ostacolo2.setOstacolo(p2);
        }

        /// <summary>
        /// metodo che cenera automaticamente sue numeri che devono essere dei limuti nei quali rientrano le coodinate dei punti
        /// da generare casualmente
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        public int randInt(int min, int max)
        {
            Random rand = new Random();
            int randomNum;
            do
            {
                randomNum = rand.Next((max - min) + 1) + min;
            } while (randomNum < min || randomNum > max);
            return randomNum;
        }

        /////  riceve un personaggio in pers e restituisce true se pers 
        /////si sovrappone a rettangolo1 o rettangolo2.Altrimenti restituisce false
        ///// <param name="pers">personaggio da controllare
        ///// <returns>booleano che indica se il personaggio HA colpito 
        //public void colpito(Personaggio pers)
        //{


        //}

        public Image getImage1()
        {
            return ostacolo1.getImage();

        }
        public Image getImage2()
        {
            return ostacolo2.getImage();

        }

    }
}
