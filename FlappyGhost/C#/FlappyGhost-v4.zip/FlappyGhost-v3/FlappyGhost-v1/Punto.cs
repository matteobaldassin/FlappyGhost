﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Punto
    {
        private Point punto;

        public Punto()
        {
            punto.X = 0;
            punto.Y = 0;
        }
        /// <summary>
        /// Inizializza l'oggetto Punto avendo in ingresso le coordinate
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public Punto(Point p)
        {
            this.punto = p;
        }

        public Punto(int x, int y)
        {
            this.punto.X = x;
            this.punto.Y = y;
        }

        /// <summary>
        /// Cambia il valore di Y
        /// </summary>
        /// <param name="y"></param>
        public void setY(int y)
        {
            this.punto.Y = y;
        }
        /// <summary>
        /// Cambia il valore di X
        /// </summary>
        /// <param name="x"></param>
        public void setX(int x)
        {
            this.punto.X = x;
        }
        public int getX() { return punto.X; }
        public int getY() { return punto.Y; }

        public void sposta(int newX, int newY)
        {
            this.punto.X += newX;
            this.punto.Y += newY;
        }

        public Point getPunto()
        {
            return punto;
        }
    }
}
