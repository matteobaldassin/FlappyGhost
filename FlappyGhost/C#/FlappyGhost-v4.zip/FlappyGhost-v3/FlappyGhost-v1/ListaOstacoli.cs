﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class ListaOStacoli
    {
        Ostacoli[] lista;
        int numEl;
        int punteggio;


        public ListaOStacoli()
        {
            punteggio = 0;
            numEl = 0;
        }

        public void add(Ostacoli insert)
        {
            lista[numEl++] = insert;
        }
        public int getNumEl()
        {
            return numEl;
        }
        //public bool superato(Personaggio Pers)
        //{
        //    if (lista[1].getOStacolo1().get)


        //}




    }
}
