﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost_v3
{
    public partial class GameControl : UserControl
    {

        int OffsetX = 0;

        private Ostacolo ostacolo1 = null;
        private Ostacolo ostacolo2 = null;
        private Ostacoli ostacoli = null;
        int Pos = 0;
        int MovimentoMassimo = 1;


        Point Ghost = new Point(0, 0);
        Personaggio personaggio = new Personaggio();


        public GameControl()
        {
            InitializeComponent();
            ostacolo1 = new Ostacolo();
            ostacolo2 = new Ostacolo();
            ostacoli = new Ostacoli(ostacolo1, ostacolo2);
            timer1.Enabled = true;
            pictureBox1.Location = new Point(-200, -200);
        }

        //protected override void OnPaint(PaintEventArgs e)
        //{
        //    base.OnPaint(e);
        //    e.Graphics.DrawImage(pictureBox1.Image, personaggio.getPosizione());
        //}

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            //base.OnPaintBackground(e);
            //e.Graphics.ScaleTransform(0.5f, 0.5f);
            int W = this.Width, H = this.Height;
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX, 0, W,H);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + this.BackgroundImage.Width, 0, W, H);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + (this.BackgroundImage.Width * 2), 0, W, H);

           // e.Graphics.DrawImage((Image)FlappyGhost.Properties.Resources, ostacolo1.getOstacolo());

           // e.Graphics.DrawImage((Image)FlappyGhost.Properties.Resources.Sottosopra, ostacolo2.getOstacolo());

            //if (Ghost.Y > Pos)
            //{
            //    if (Ghost.Y - MovimentoMassimo > Pos)
            //        Ghost = new Point(Ghost.X, Ghost.Y - MovimentoMassimo);
            //    else
            //        Ghost = new Point(Ghost.X, Pos);
            //}
            //else if (Ghost.Y < Pos)
            //{
            //    if (Ghost.Y + MovimentoMassimo < Pos)
            //        Ghost = new Point(Ghost.X, Ghost.Y + MovimentoMassimo);
            //    else
            //        Ghost = new Point(Ghost.X, Pos);
            //}

            //if (personaggio.getNumImmagine() == 1)
            //{


            //    e.Graphics.DrawImage(pictureBox1.Image, ghost);
            //    int distanza = sensore.getValore();

            //    fineGioco = personaggio.mossa(distanza, ostacoli);
            //    personaggio.getCentro();

            //}
        }

       

        private void timer1_Tick(object sender, EventArgs e)
        {
            OffsetX -= 10;
            if (OffsetX < -this.BackgroundImage.Width)
            {
                OffsetX += this.BackgroundImage.Width;
            }
            Invalidate();
        }
    }
}
