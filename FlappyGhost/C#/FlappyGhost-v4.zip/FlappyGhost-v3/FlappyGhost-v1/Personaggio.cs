﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost_v3
{
    class Personaggio
    {
        private Punto pos;
        private Rettangolo rect;
        private int distanzaDaSuolo;
        private Image img;
        private Punto centro;
        private int velocita { get; set; }

        public Personaggio()
        {
            pos = new Punto(30, 410);
            distanzaDaSuolo = 0;
            velocita = 10;
            rect = new Rettangolo(pos, img.Width, img.Height);
        }
        /**
         * costruttore dove vengono passati i parametri e vengono creati gli oggetti sottostanti
         * @param dimensione
         * @param distanzaDaSuolo
         * @param centro 
         */
        public Personaggio(Rettangolo rett, int distanzaDaSuolo, Punto centro)
        {
            //pos.SetBounds(rett.altoSx.getX(), rett.altoSx.getY(), rett.width, rett.height);
            this.distanzaDaSuolo = distanzaDaSuolo;
            this.centro = centro;
        }
        //public void sposta(Keys tasto)
        //{
        //    System.Drawing.Point pt = this.Location;

        //    if (tasto == Keys.Up)
        //        pt.Y -= velocita;
        //    else if (tasto == Keys.Down)
        //        pt.Y += velocita;
        //    else if (tasto == Keys.Right)
        //        pt.X += velocita;
        //    else if (tasto == Keys.Left)
        //        pt.X -= velocita;

        //    this.Location = pt;

        //}
        public void setImage(Image ghost)
        {
            this.img = ghost;
        }
        public int getWidth()
        {
            return img.Width;
        }
        public int getHeight()
        {
            return img.Height;
        }
        public bool scontrato(ListaOstacoli[] coppie)
        {
            bool scontrato = false;
            for (int i = 0; i < coppie.getNumEl(); i++)
            {
                if (coppie[i].getOstacolo1.getRect().IntersectWith(rect.getRect)){

                    scontrato = true;
                }
                else if (coppie[i].getOstacolo2.getRect().IntersectWith(rect.getRect)){
                scontrato = true;
            }
                return scontrato;
            }
        }
        public int getDistanzaDaSuolo()
        {
            return distanzaDaSuolo;
        }

        public void setDistanzaDaSuolo(int distanzaDaSuolo)
        {
            this.distanzaDaSuolo = distanzaDaSuolo;
        }

        public Punto getCentro()
        {
            return centro;
        }
        public Punto getPos()
        {
            return pos;
        }
        public Point getPosizione()
        {
            return pos.getPunto();
        }
        public void setCentro(Punto centro)
        {
            this.centro = centro;
        }
        /**
         * imposta l'altezza del personaggio, riprendendo il valore passato
         * dalla porta seriale
         * @param valore valore passato dalla porta seriale
         * @return il valore della posizione sull'asse Y del fantasmino
         */
        public int setAltezza(int valore)
        {
            centro.setX(valore);
            return valore;
        }
        /*
        public bool scontrato(PictureBox bird)
        {
            bool ris = false;
            ris = this.Bounds.IntersectsWith(bird.Bounds);
            return ris;


        }
        */
    }
}
