﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Global.Init();

            gameControl1.ShowMenuControl += GameControl1_ShowMenuControl;
            menuControl1.RestartGame += MenuControl1_RestartGame;

            
            
            
        }

        private void MenuControl1_RestartGame()
        {
            menuControl1.Visible = false;
            gameControl1.Init();

        }

        private void GameControl1_ShowMenuControl(bool Visible)
        {
            menuControl1.Visible = Visible;



        }


       /* public void ShowGameControl()
        {
            Controls.Add(gameControl1);
            Controls.Remove(menuControl1);
            Invalidate();
        }
        public void ShowMenuControl()
        {
            
            Controls.Add(menuControl1);
            Controls.Remove(gameControl1);
        }*/


    }
}
