﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace FlappyGhost
{
    public partial class GameControl : UserControl
    {

        int OffsetX = 0;
        bool Morte = false;
        ListaOstacoli Lista = null;
        Point puntoMuro;
        int secondi = 0, minuti = 0;
        Point Ghost = new Point(0, 0);
        Personaggio personaggio = new Personaggio();

        


        /// <summary>
        /// Gestisce tutto il gioco
        /// </summary>
        public GameControl()
        {
            InitializeComponent();
            Init();
            timerClock.Enabled = true;
        }

        public void Init()
        {

            puntoMuro = new Point(0, 658);
            Morte = false;
            timerSfondo.Enabled = true;
            Lista = new ListaOstacoli();
            Image sopra = FlappyGhost.Properties.Resources.tubo_dritto;
            Image sotto = FlappyGhost.Properties.Resources.tubo_contrario;
            Lista.Add(new Ostacoli(new Ostacolo(new Punto(1280, 300 - sopra.Height), sopra), new Ostacolo(new Punto(1280, 500), sotto)));
            Lista.Add(new Ostacoli(new Ostacolo(new Punto(1756, 300 - sopra.Height), sopra), new Ostacolo(new Punto(1756, 500), sotto)));
            Lista.Add(new Ostacoli(new Ostacolo(new Punto(2232, 300 - sopra.Height), sopra), new Ostacolo(new Punto(2232, 500), sotto)));
            timerClock.Enabled = true;
        }

        /// <summary>
        /// Disegna il background
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            
            int W = this.Width, H = this.Height;
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX, 0, W, H);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + this.BackgroundImage.Width, 0, W, H);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + (this.BackgroundImage.Width * 2), 0, W, H);

        }

        /// <summary>
        /// Disegna i Personaggi
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            //Disegna Personaggio
            e.Graphics.DrawImage(personaggio.getImage(), personaggio.getPosizione());

            //Disegna Ostacoli
            try
            {
                e.Graphics.DrawImage(Lista.GetAt(0).getOstacoloSopra().getImage(), Lista.GetAt(0).getOstacoloSopra().getPuntoOstacolo().getPunto());
                e.Graphics.DrawImage(Lista.GetAt(0).getOstacoloSotto().getImage(), Lista.GetAt(0).getOstacoloSotto().getPuntoOstacolo().getPunto());
            }
            catch (Exception exc)
            {
                Console.Write(exc.ToString());
            }
            try
            {
                e.Graphics.DrawImage(Lista.GetAt(1).getOstacoloSopra().getImage(), Lista.GetAt(1).getOstacoloSopra().getPuntoOstacolo().getPunto());
                e.Graphics.DrawImage(Lista.GetAt(1).getOstacoloSotto().getImage(), Lista.GetAt(1).getOstacoloSotto().getPuntoOstacolo().getPunto());
            }
            catch (Exception exc)
            {
                Console.Write(exc.ToString());
            }
            try
            {
                e.Graphics.DrawImage(Lista.GetAt(2).getOstacoloSopra().getImage(), Lista.GetAt(2).getOstacoloSopra().getPuntoOstacolo().getPunto());
                e.Graphics.DrawImage(Lista.GetAt(2).getOstacoloSotto().getImage(), Lista.GetAt(2).getOstacoloSotto().getPuntoOstacolo().getPunto());
            }
            catch (Exception exc)
            {
                Console.Write(exc.ToString());
            }

            //int W = FlappyGhost.Properties.Resources.wallpaper_muro.Width, H = FlappyGhost.Properties.Resources.wallpaper_muro.Height;
            //e.Graphics.DrawImage(FlappyGhost.Properties.Resources.wallpaper_muro, OffsetMuroX, 658, W, H);
            //e.Graphics.DrawImage(FlappyGhost.Properties.Resources.wallpaper_muro, OffsetMuroX + FlappyGhost.Properties.Resources.wallpaper_muro.Width, 658, W, H);
            //e.Graphics.DrawImage(FlappyGhost.Properties.Resources.wallpaper_muro, OffsetMuroX + (FlappyGhost.Properties.Resources.wallpaper_muro.Width * 2), 658, W, H);


            if (Morte == true)
            {
                //e.Graphics.DrawImage(FlappyGhost.Properties.Resources.sei_morto,this.Height/2,this.Width/2);
                ShowMenuControl?.Invoke(true);
                secondi = 0;
                minuti = 0;
                label1.Text = secondi.ToString();
                timerClock.Enabled = false;

            }
        }

        /// <summary>
        /// Sposta ad ogni tick l'immagine di sfondo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timerSfondo_Tick(object sender, EventArgs e) // TimerSfondo perchè non lo fa rinominare
        {
            //Disegno Sfondo
            OffsetX -= 10;
            if (OffsetX < -this.BackgroundImage.Width)
            {
                OffsetX += this.BackgroundImage.Width;
            }

            //Disegno Personaggio
            personaggio.getGestioneFrameImage().Start();
            personaggio.aggiorna();
            personaggio.aggiornaImage();

            //Disegno Ostacoli
            //creaOstacolo();
            try
            {
                Lista.Avanza(10);
                
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }

            //Controllo scontro con un palo
            Morte = personaggio.muori(Lista);
            
            if (Morte==true)
            {
               
                    timerSfondo.Enabled = false;

                //MessageBox.Show("Morto");
                
            }

            //Punteggio
            Lista.Superato(personaggio);
            

            Invalidate();
        }



        public event ShowMenuControlDelegate ShowMenuControl;

        private void timerClock_Tick(object sender, EventArgs e)
        {
            

            if (secondi < 60)
            {
                secondi++;
            }
            if (secondi > 60)
            {
                minuti++;
                secondi = 0;
            }
            label1.Text = minuti.ToString() + secondi.ToString();
        }
    }

    public delegate void ShowMenuControlDelegate(bool Visible);
}
