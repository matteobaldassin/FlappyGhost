﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Ostacoli
    {
        private Ostacolo ostacoloSopra;
        private Ostacolo ostacoloSotto;

        public Ostacoli()
        {
            ostacoloSopra = new Ostacolo();
            ostacoloSotto = new Ostacolo();
        }

        /// <summary>
        /// Crea un oggetto Ostacoli ricevendo come parametro i due Ostacolo
        /// </summary>
        /// <param name="ostacoloSopra"></param>
        /// <param name="ostacoloSotto"></param>
        public Ostacoli(Ostacolo ostacoloSopra, Ostacolo ostacoloSotto)
        {
            this.ostacoloSopra = ostacoloSopra;
            this.ostacoloSotto = ostacoloSotto;
            ostacoloSopra.setImage(FlappyGhost.Properties.Resources.tubo_dritto);
            ostacoloSotto.setImage(FlappyGhost.Properties.Resources.tubo_contrario);
        }


        /// <summary>
        /// Setta l'ostacolo superiore e calcola il valore random delle y 
        /// </summary>
        /// <param name="X"></param>
        public void setOstacoloSopra(Image img)
        {
            
            ostacoloSopra.setImage(img);
            ostacoloSopra.setOstacolo(new Punto(1280,ostacoloSotto.getPuntoOstacolo().getY()-200-ostacoloSopra.getH()));
        }

        /// <summary>
        /// Setta l'ostacolo inferioire tenendo presente le coordinate di quello superiore
        /// </summary>
        public void setOstacoloSotto(Image img)
        {
            int y = randInt(600, 300);
            ostacoloSotto.setImage(img);
            ostacoloSotto.setOstacolo(new Punto(1280,y)); 
        }

        /// <summary>
        /// Restituisce un numero random da min a max
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        public int randInt(int max, int min)
        {
            Random rand = new Random();
            int randomNum;
            do
            {
                randomNum = rand.Next((max - min) + 1) + min;
            } while (randomNum < min || randomNum > max);
            return randomNum;
        }

        /// <summary>
        /// Ritorna l'immagine corrispondente all'ostacoloSopra
        /// </summary>
        /// <returns>ostacoloSopra.getImage()</returns>
        public Image getImageSopra()
        {
            return ostacoloSopra.getImage();
        }

        /// <summary>
        /// Ritorna l'immagine corrispondente all'ostacoloSotto
        /// </summary>
        /// <returns>ostacoloSotto.getImage()</returns>
        public Image getImageSotto()
        {
            return ostacoloSotto.getImage();
        }

        /// <summary>
        /// Ritorna l'ostacoloSopra
        /// </summary>
        /// <returns></returns>
        public Ostacolo getOstacoloSopra()
        {
            return ostacoloSopra;
        }

        /// <summary>
        /// Ritorna l'ostacoloSotto
        /// </summary>
        /// <returns></returns>
        public Ostacolo getOstacoloSotto()
        {
            return ostacoloSotto;
        }
    }
}
