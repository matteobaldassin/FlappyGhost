﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Personaggio
    {
        private Punto pos;
        private Rettangolo rect;
        //private int distanzaDaSuolo;
        private Image imgCorrente;
        private Punto centro;
       // private GameControl game;
        
        private GestioneFrameImage frame;
        private int velocita { get; set; }

        public Personaggio()
        {
            pos = new Punto(100, 350);
            //distanzaDaSuolo = 400;
            velocita = 10;
            imgCorrente = FlappyGhost.Properties.Resources.Ghost;
            rect = new Rettangolo(pos, imgCorrente.Width, imgCorrente.Height);
            centro = new Punto(2, 0);
            frame = new GestioneFrameImage(FlappyGhost.Properties.Resources.Ghost);
            //com = new Comunicazione();
            
        }

        /// <summary>
        /// Crea un Personaggio dato in ingresso i  rettangolo, la distanza dal suolo e il suo centro
        /// </summary>
        /// <param name="rett"></param>
        /// <param name="distanzaDaSuolo"></param>
        /// <param name="centro"></param>
        public Personaggio(Rettangolo rett, int distanzaDaSuolo, Punto centro)
        {
            //pos.SetBounds(rett.altoSx.getX(), rett.altoSx.getY(), rett.width, rett.height);
            //this.distanzaDaSuolo = distanzaDaSuolo;
            pos.setY(distanzaDaSuolo);
            this.centro = centro;
        }
        /// <summary>
        /// Aggiorna l'immagine in base al timeout del frame
        /// </summary>
        public void aggiornaImage()
        {
            imgCorrente= frame.getCorrectFrame();
        }
        /// <summary>
        /// Metodo che imposta l'immagine del personaggio
        /// </summary>
        /// <param name="ghost"></param>
        public void setImage(Image ghost)
        {
            this.imgCorrente = ghost;
        }

        /// <summary>
        /// Metodo che ritorna la lunghezza dell'immagine
        /// </summary>
        /// <returns></returns>
        public int getWidth()
        {
            return imgCorrente.Width;
        }

        /// <summary>
        /// Metodo che ritorna la larghezza dell'immagine
        /// </summary>
        /// <returns></returns>
        public int getHeight()
        {
            return imgCorrente.Height;
        }
        public void aggiorna()
        {
            int valore = Global.com.getValore();
            pos.setY(720-valore);
            if(pos.getY() > 720)
                pos.setY(720);
            if(pos.getY() <0)
                pos.setY(100);


        }
        /// <summary>
        /// Controlla se si è scontrato con degli ostacoli e ritorna true o false
        /// </summary>
        /// <param name="coppie"></param>
        /// <returns></returns>
        public bool scontrato(ListaOstacoli coppie)
        {
            bool scontrato = false;
           
            
                
                if (coppie.GetAt(0).getOstacoloSotto().getRect().IntersectsWith(this.getRect()))
                {
                    scontrato = true;
                }
            if (coppie.GetAt(0).getOstacoloSopra().getRect().IntersectsWith(this.getRect()))
                {

                    scontrato = true;
                }
            
            return scontrato;

        }


        /// <summary>
        /// Cade verso la sua morte 
        /// </summary>
        /// <param name="coppie"></param>
        public bool muori(ListaOstacoli coppie)
        {
            bool morto = false;
            if (scontrato(coppie))
            {
                while (pos.getY()/*distanzaDaSuolo*/ <= 720-rect.getRect().Height)
                {
                    pos.setY(pos.getY()+10);
                }
                morto = true;

            }
            return morto;
        }

        /// <summary>
        /// Ritorna la distanza da suolo
        /// </summary>
        /// <returns></returns>
        public int getDistanzaDaSuolo()
        {
            return pos.getY();
        }

        /// <summary>
        /// Setta la distanza dal suolo
        /// </summary>
        /// <param name="distanzaDaSuolo"></param>
        public void setDistanzaDaSuolo(int distanzaDaSuolo)
        {
            pos.setY(distanzaDaSuolo);
            if (pos.getY() > 720) // 720 e' la gameSize, cioe l'altezza del form
                pos.setY(720);
        }

        /// <summary>
        /// Ritorna il centro
        /// </summary>
        /// <returns></returns>
        public Punto getCentro()
        {
            return centro;
        }

        /// <summary>
        /// Ritorna la posizione
        /// </summary>
        /// <returns></returns>
        public Punto getPos()
        {
            return pos;
        }

        /// <summary>
        /// Ritorna la posizione sotto forma di System.Drawing.Point
        /// </summary>
        /// <returns></returns>
        public Point getPosizione()
        {
            return pos.getPunto();
        }

        /// <summary>
        /// Setta il centro
        /// </summary>
        /// <param name="centro"></param>
        public void setCentro(Punto centro)
        {
            this.centro = centro;
        }

        /// <summary>
        /// Setta l'altezza
        /// </summary>
        /// <param name="valore"></param>
        /// <returns></returns>
        public int setAltezza(int valore)
        {
            centro.setX(valore);
            return valore;
        }
        
        /// <summary>
        /// Ritorna il Rectangle del personaggio
        /// </summary>
        /// <returns></returns>
        public Rectangle getRect()
        {
            return new Rettangolo(pos, imgCorrente.Width, imgCorrente.Height).getRect(); 
        }
        /// <summary>
        /// Ritorna l'immagine del personaggio
        /// </summary>
        /// <returns></returns>
        public Image getImage()
        {
            return imgCorrente;
        }

        public GestioneFrameImage getGestioneFrameImage()
        {
            return frame;
        }
    }
}
