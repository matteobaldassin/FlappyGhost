﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Rettangolo
    {
        private Rectangle rect;

        //public Punto altoSx { set; get; }
        //public int width { set; get; }
        //public int height { set; get; }

        /// <summary>
        /// Crea un oggettp di tipo Rettangolo ricevendo come parametri il punto in alto a sinistra la larghezza e l'altezza 
        /// </summary>
        /// <param name="altoSx"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public Rettangolo(Punto altoSx, int width, int height)
        {
            rect.Location = altoSx.getPunto();
            rect.Width = width;
            rect.Height = height;

        }
        
        public Rettangolo()
        {
            rect.Location = new Punto(0, 0).getPunto();
            rect.Height = 0;
            rect.Width = 0;
        }
        /// <summary>
        /// Restituisce l'oggetto rettangolo come tipo System.Drawing.Rectangle
        /// </summary>
        /// <returns></returns>
        public Rectangle getRect()
        {
            return rect;

        }
    }
}
