﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FlappyGhost
{
    class ListaOstacoli
    {
        private Ostacoli[] lista = new Ostacoli[3];
        private int numEl;
        
        public ListaOstacoli()
        {
            numEl = 0;
        }

        /// <summary>
        /// aggiunge un oggetto ostacoli nel vettore
        /// </summary>
        /// <param name="insert"></param>
        public void Add(Ostacoli insert)
        {
            try
            {
                lista[numEl] = insert;
                numEl++;
            }
            catch (Exception e)
            {
                Console.Write(e.ToString());
            }
        }
        /// <summary>
        /// Ritorna il numero degli elementi
        /// </summary>
        /// <returns></returns>
        public int GetNumEl()
        {
            return numEl;
        }


        /// <summary>
        /// Riceve un personaggio e incrementa punteggio quando il personaggio riesce a superare una coppia di ostacoli
        /// </summary>
        /// <param name="pers"></param>
        /// <returns></returns>
        public void Superato(Personaggio pers)
        {
            
           

            int sup = pers.getPos().getX() - (lista[0].getOstacoloSopra().getPuntoOstacolo().getX() + lista[0].getOstacoloSopra().getW());

           
              
            
        }
        
        /// <summary>
        /// Metodo per creare gli ostacoli, ad ogni inserimento aumenta la x di ogni ostacolo della costante "distanzaOstacoliX" 
        /// </summary>
        public void CreaOstacoli()
        {
            Ostacoli insert = new Ostacoli();
            insert.setOstacoloSotto(FlappyGhost.Properties.Resources.tubo_contrario);
            insert.setOstacoloSopra(FlappyGhost.Properties.Resources.tubo_dritto);
            
            Add(insert);
        }


        /// <summary>
        /// Il metodo che restituisce il puntegio del giocatore
        /// </summary>
        /// <returns></returns>
       
        /// <summary>
        /// Restituisce l'Ostacolo in posizione pos
        /// </summary>
        /// <param name="pos"></param>
        /// <returns></returns>
        public Ostacoli GetAt(int pos)
        {
            return lista[pos];
        }

        /// <summary>
        /// Restituisce l'ostacolo che il Personaggio sta superando o che deve superare
        /// </summary>
        /// <param name="pers"></param>
        /// <returns></returns>
        //public int GetOst(Personaggio pers)
        //{
        //    int temp = 0;
        //    if (numEl > 0)
        //    {
        //        for (int i = numEl-1; i > 0; i--)
        //            if (pers.getPos().getX() < (lista[i].getOstacoloSopra().getPuntoOstacolo().getX() + lista[i].getOstacoloSopra().getW()))
        //            {
        //                temp = i;
        //            }
        //    }
        //    return temp;
        //}
        
        /// <summary>
        /// Diminuisce di un valore la x di tutti gli ostacoli presenti nel vettore
        /// </summary>
        /// <param name="valore"></param>
        public void Avanza(int valore)
        {
            for (int n = 0; n < numEl;n++)
            {
                lista[n].getOstacoloSopra().getPuntoOstacolo().setX(lista[n].getOstacoloSopra().getPuntoOstacolo().getX() - valore);
                lista[n].getOstacoloSotto().getPuntoOstacolo().setX(lista[n].getOstacoloSotto().getPuntoOstacolo().getX() - valore);
            }
            EliminaOstacolo();
         
        }

        /// <summary>
        /// Shift a sinistra del vettore di ostacoli
        /// </summary>
        public void Shift()
        {
            for (int i = 0;i < numEl -1 ; i++)
            {
                lista[i] = lista[i+1];
               
            }
            numEl--;
            
        }

        /// <summary>
        /// Elimina l'ostacolo che è uscito dallo schermo
        /// </summary>
        public void EliminaOstacolo()
        {
            if (lista[0].getOstacoloSopra().getPuntoOstacolo().getX()+ lista[0].getOstacoloSopra().getW()<= 0)
            {
                Shift();
                CreaOstacoli();
            }
        }
    }
}
