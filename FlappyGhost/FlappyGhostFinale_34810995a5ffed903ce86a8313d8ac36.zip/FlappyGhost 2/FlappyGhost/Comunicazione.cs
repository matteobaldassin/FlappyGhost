﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Comunicazione
    {
        private int valore;
        private SerialPort porta=null;
        private string inData;
       
        /// <summary>
        /// Costruttore di default che inizializza tutti gli attributi
        /// SerialPort porta = new SerialPort("COM4", 9600) inizializza la porta con il numero di porta(COM3) e il baud rate(9600)
        /// porta.Open()= apre la porta seriale
        /// </summary>
        public Comunicazione()
        {

                valore = 0;
                porta = new SerialPort("COM3", 9600);
                porta.DataReceived += leggiSeriale;
                //bool b = false;
                //do
                //{

                //    try
                //    {
                porta.Open();
                //        b = true;
                //    }
                //    catch (Exception ex)
                //    {
                //        Console.Write(ex.ToString());
                //    }

                //} while (b != true);
            

        }

        /// <summary>
        /// Metodo che riceve tramite porta seriale dei valori letti dal rilevatore di distanza con arduino
        /// </summary>
        /// <param name="s"></param>
        /// <param name="e"></param> fornisce i dati per l'evento DataReceived
        public void leggiSeriale(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                SerialPort porta = (SerialPort)sender;
                inData = porta.ReadLine();
                valore = int.Parse(inData);
            }
            catch (Exception ee)
            {
                Console.Write(ee.ToString());
            }
            //return valore;
        }
        /// <summary>
        /// Ritorna il valore della variabile valore
        /// </summary>
        /// <returns></returns>
        public int getValore()
        {
            //leggiSeriale();
            return valore;
        }
    }
}
