﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class GestioneFrameImage
    {
        public int numEl { set; get; }
        private Image gifImg;
        FrameDimension dimension = null;
        int delay = 0;

        int Index = 0;
        Stopwatch watch;

        /// <summary>
        /// Crea l'oggetto GestioneFrameimage
        /// </summary>
        /// <param name="gif"></param>
        public GestioneFrameImage(Image gif)
        {
            this.gifImg = gif;
            dimension = new FrameDimension(gifImg.FrameDimensionsList[0]);
            numEl = gifImg.GetFrameCount(dimension);

            PropertyItem item = gifImg.GetPropertyItem(0x5100); // FrameDelay in libgdiplus
                                                                // Time is in 1/100ths of a second
            delay = (item.Value[0] + item.Value[1] * 256) * 10;
            watch = new Stopwatch();
        }

        /// <summary>
        /// setta il frame della gif in modo che sia sincronizzato rispetto al normale delay tra frame della gif
        /// </summary>
        /// <param name="index"></param>
        public Image getCorrectFrame()
        {
            //Calcolo in base al T passato dalla scorsa stampa il frame corretto
            long trascorso = watch.ElapsedMilliseconds;
            int FramePassati = (int)(trascorso / delay);
            int OldIndex = Index;
            Index += FramePassati;
            Index = Index % numEl;

            if (OldIndex != Index)
            {
                gifImg.SelectActiveFrame(dimension, Index);
                restart();
            }
            /*if (trascorso < delay)
            {
                gifImg.SelectActiveFrame(dimension, 0);
            }
            else if (trascorso < 2 * delay)
            {
                gifImg.SelectActiveFrame(dimension, 1);
            }
            else if (trascorso < 3 * delay)
            {
                gifImg.SelectActiveFrame(dimension, 2);
            }
            else
            {
                gifImg.SelectActiveFrame(dimension, 3);

                if (trascorso >= 4 * delay) restart();
            }*/
            return gifImg;
        }


        public Image img
        {
            get
            {
                return gifImg;
            }
        }

        /// <summary>
        /// fa partire il cronometro per il delay dei frame
        /// </summary>
        public void Start()
        {
            watch.Start();
        }
        /// <summary>
        /// stoppa il cronometro per il delay dei frame 
        /// </summary>
        public void Stop()
        {
            watch.Stop();
        }
        /// <summary>
        /// restarta il cronometro
        /// </summary>
        public void restart()
        {
            watch.Restart();
        }
    }
}
