﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    static class Global
    {
        public static Comunicazione com;
        static public void Init()
        {
            com = new Comunicazione();
        }
    }
}
