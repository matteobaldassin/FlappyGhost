﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Ostacolo
    {
        private Punto ostacolo { set; get; }

        private Image img;
        private Rettangolo rect;
        /// <summary>
        /// Crea un Oggetto di tipo Ostacolo ricevendo in ingresso il punto e la sua immagine
        /// </summary>
        /// <param name="altoSx"></param>
        /// <param name="immag"></param>
        public Ostacolo(Punto altoSx ,Image immag)
        {
            ostacolo = altoSx;
            img = immag;
            rect = new Rettangolo(altoSx, img.Width, img.Height);
        }

        public Ostacolo()
        {
            ostacolo = new Punto();
            rect = new Rettangolo();
        }

        /// <summary>
        /// Metodo che restituisce un System.Drawing.Point corrispondente al punto in alto a sinistra del rettangolo
        /// </summary>
        /// <returns></returns>
        public Point getOstacolo()
        {
            return ostacolo.getPunto();
        }

        /// <summary>
        /// Metodo che restituisce un Punto corrispondente al punto in alto a sinistra del rettangolo
        /// </summary>
        /// <returns></returns>
        public Punto getPuntoOstacolo()
        {
            return ostacolo;
        }

        /// <summary>
        /// Setta il punto in alto a sinistra del rettangolo
        /// </summary>
        /// <param name="p"></param>
        public void setOstacolo(Punto p)
        {
            ostacolo = p;
        }

        /// <summary>
        /// Restituisce il valore della larghezza dell' immagine dell' ostacolo
        /// </summary>
        /// <returns>img.Width</returns>
        public int getW()
        {
            return img.Width;
        }

        /// <summary>
        /// Restituisce il valore dell' altezza dell' immagine dell' ostacolo
        /// </summary>
        /// <returns>img.Height</returns>
        public int getH()
        {
            return img.Height;
        }

        /// <summary>
        /// Setta l' immagine dell'ostacolo
        /// </summary>
        /// <param name="ost"></param>
        public void setImage(Image ost)
        {
            this.img = ost;
        }

        /// <summary>
        /// Metodo per restituire l'attributo dell' ostacolo img
        /// </summary>
        /// <returns>img</returns>
        public Image getImage()
        {
            return img;
        }
        /// <summary>
        /// Restituisce il rettangolo convertito in System.Drawing.Rectangle
        /// </summary>
        /// <returns></returns>
        public Rectangle getRect()
        {
            Rectangle rect = new Rectangle(ostacolo.getX(), ostacolo.getY(), getW(),getH());
            return rect;
        }

    }
}
