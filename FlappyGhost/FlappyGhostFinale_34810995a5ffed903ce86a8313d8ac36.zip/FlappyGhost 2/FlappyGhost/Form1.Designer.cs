﻿using System.Windows.Forms;
using System;
using System.Drawing;
namespace FlappyGhost
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.gameControl1 = new FlappyGhost.GameControl();
            this.menuControl1 = new FlappyGhost.MenuControl();
            this.SuspendLayout();
            // 
            // gameControl1
            // 
            this.gameControl1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gameControl1.BackgroundImage")));
            this.gameControl1.Location = new System.Drawing.Point(0, -37);
            this.gameControl1.Name = "gameControl1";
            this.gameControl1.Size = new System.Drawing.Size(1280, 720);
            this.gameControl1.TabIndex = 0;
            // 
            // menuControl1
            // 
            this.menuControl1.BackColor = System.Drawing.Color.Transparent;
            this.menuControl1.Location = new System.Drawing.Point(0, 0);
            this.menuControl1.Name = "menuControl1";
            this.menuControl1.Size = new System.Drawing.Size(1280, 720);
            this.menuControl1.TabIndex = 1;
            this.menuControl1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1278, 681);
            this.Controls.Add(this.menuControl1);
            this.Controls.Add(this.gameControl1);
            this.Name = "Form1";
            this.Text = "FlappyGhost Game";
            this.ResumeLayout(false);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;




        }

        #endregion

        private GameControl gameControl1;
        private MenuControl menuControl1;
    }
}

