﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyGhost
{

    public partial class MenuControl : UserControl 
    {
        int punteggio;
        int OffsetX = 0;


        public int Punteggio
        {
            get
            {
                return punteggio;
            }

            set
            {
                punteggio = value;
            }
        }

        public MenuControl()
        {
            InitializeComponent();
            timer1.Enabled = true;
                     
        }

        private void Restart_Click(object sender, EventArgs e)
        {
            RestartGame?.Invoke();
        }

        public event RestartGameDelegate RestartGame;

        private void LabelPunteggio_Click(object sender, EventArgs e)
        {
            
        }
        protected override void OnPaintBackground(PaintEventArgs e)
        {

            int W = this.Width, H = this.Height;
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX, 0, W, H);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + this.BackgroundImage.Width, 0, W, H);
            e.Graphics.DrawImage(this.BackgroundImage, OffsetX + (this.BackgroundImage.Width * 2), 0, W, H);

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Creatori:\n\nMatteo Baldassin\nAlberto Limonta\nGianluca Cattaneo\nTrezzi Luca\n4A Informatica", "Creatori",
            MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Disegno Sfondo
            OffsetX -= 10;
            if (OffsetX < -this.BackgroundImage.Width)
            {
                OffsetX += this.BackgroundImage.Width;
            }
            Invalidate();
        }
    }

    public delegate void RestartGameDelegate();
}
