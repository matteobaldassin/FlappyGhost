﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlappyGhost
{
    class Punto
    {
        private Point punto;

        public Punto()
        {
            punto.X = 0;
            punto.Y = 0;
        }
        /// <summary>
        /// Inizializza l'oggetto Punto avendo in ingresso un System.Drawing.Point
        /// </summary>
        /// <param name="p"></param>
        public Punto(Point p)
        {
            this.punto = p;
        }
        /// <summary>
        /// Crea un nuovo punto a partire dalle coordinate
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public Punto(int x, int y)
        {
            this.punto.X = x;
            this.punto.Y = y;
        }

        /// <summary>
        /// Cambia il valore di Y
        /// </summary>
        /// <param name="y"></param>
        public void setY(int y)
        {
            this.punto.Y = y;
        }
        /// <summary>
        /// Cambia il valore di X
        /// </summary>
        /// <param name="x"></param>
        public void setX(int x)
        {
            this.punto.X = x;
        }
        /// <summary>
        /// Ritorna il valore di X
        /// </summary>
        /// <returns></returns>
        public int getX() { return punto.X; }
        /// <summary>
        /// Ritorna il valore di Y
        /// </summary>
        /// <returns></returns>
        public int getY() { return punto.Y; }

        /// <summary>
        /// Sposta la x del punto di newX e la y di newY
        /// </summary>
        /// <param name="newX"></param>
        /// <param name="newY"></param>
        public void sposta(int newX, int newY)
        {
            this.punto.X += newX;
            this.punto.Y += newY;
        }

        /// <summary>
        /// Ritorna il Punto come oggetto della classe System.Drawing.Point
        /// </summary>
        /// <returns></returns>
        public Point getPunto()
        {
            return punto;
        }
    }
}

